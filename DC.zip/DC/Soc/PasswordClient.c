#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int sock;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];

    // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        return -1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);

    // Convert IPv4 and IPv6 addresses from text to binary form
    if (inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr) <= 0) {
        perror("Invalid address");
        close(sock);
        return -1;
    }

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(sock);
        return -1;
    }

    // Receive welcome message from server
    int read_size = recv(sock, buffer, sizeof(buffer), 0);
    if (read_size <= 0) {
        perror("recv failed");
        close(sock);
        return -1;
    }
    buffer[read_size] = '\0';
    printf("%s", buffer);

    // Send password to server
    printf("Enter your password: ");
    fgets(buffer, sizeof(buffer), stdin);
    buffer[strcspn(buffer, "\n")] = 0; // Remove the newline character from input

    send(sock, buffer, strlen(buffer), 0);

    // Receive the validation result
    read_size = recv(sock, buffer, sizeof(buffer), 0);
    if (read_size > 0) {
        buffer[read_size] = '\0';
        printf("%s", buffer);
    }

    close(sock);
    return 0;
}

