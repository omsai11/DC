import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class PasswordServer {

    // Function to validate the password
    private static boolean validatePassword(String password) {
        return password.length() >= 8; // Password must be at least 8 characters
    }

    // Runnable to handle client connections
    static class ClientHandler implements Runnable {
        private Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true)) {

                // Send a welcome message to the client
                writer.println("Welcome to the Password Validator Server! Please enter your password:");

                // Receive password from the client
                String password = reader.readLine();

                // Validate the password
                if (validatePassword(password)) {
                    writer.println("Password is valid.");
                } else {
                    writer.println("Password is invalid. Must be at least 8 characters long.");
                }

            } catch (IOException e) {
                System.out.println("Error handling client: " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                } catch (IOException e) {
                    System.out.println("Error closing socket: " + e.getMessage());
                }
            }
        }
    }

    public static void main(String[] args) {
        int port = 8080;
        ExecutorService executor = Executors.newFixedThreadPool(10);

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server is listening on port " + port);

            // Continuously accept new client connections
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected: " + clientSocket.getInetAddress());

                // Handle the client in a new thread
                executor.submit(new ClientHandler(clientSocket));
            }

        } catch (IOException e) {
            System.out.println("Error starting the server: " + e.getMessage());
        } finally {
            executor.shutdown();
        }
    }
}

