import java.io.*;
import java.net.*;

public class PasswordClient {

    public static void main(String[] args) {
        String serverAddress = "127.0.0.1";  // Server IP address
        int port = 8080;  // Server port
        BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));

        try (Socket socket = new Socket(serverAddress, port);
             BufferedReader serverReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter serverWriter = new PrintWriter(socket.getOutputStream(), true)) {

            // Read and display the server's welcome message
            String serverMessage = serverReader.readLine();
            System.out.println(serverMessage);

            // Read password input from the user
            System.out.print("Enter your password: ");
            String password = consoleReader.readLine();

            // Send the password to the server
            serverWriter.println(password);

            // Receive the server's response about the password validity
            String response = serverReader.readLine();
            System.out.println(response);

        } catch (IOException e) {
            System.out.println("Error connecting to the server: " + e.getMessage());
        }
    }
}

