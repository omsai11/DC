#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>

#define PORT 8080
#define MAX_CLIENTS 10
#define BUFFER_SIZE 1024

// Function to validate the password
int validate_password(char *password) {
    if (strlen(password) >= 8) {
        return 1; // Valid password
    }
    return 0; // Invalid password
}

// Function to handle client requests
void *handle_client(void *arg) {
    int new_sock = *((int *)arg);
    free(arg); // Free the memory allocated for the socket

    char buffer[BUFFER_SIZE];
    int read_size;

    // Send a welcome message
    char *welcome_message = "Welcome to the Password Validator Server! Please enter a password: ";
    send(new_sock, welcome_message, strlen(welcome_message), 0);

    // Receive password from client
    read_size = recv(new_sock, buffer, sizeof(buffer), 0);
    if (read_size <= 0) {
        perror("recv failed");
        close(new_sock);
        return NULL;
    }

    buffer[read_size] = '\0'; // Null-terminate the received string

    // Check if the password is valid
    if (validate_password(buffer)) {
        send(new_sock, "Password is valid.\n", 18, 0);
    } else {
        send(new_sock, "Password is invalid. Must be at least 8 characters long.\n", 58, 0);
    }

    close(new_sock);
    return NULL;
}

int main() {
    int server_fd, new_sock, *new_sock_ptr;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    pthread_t thread_id;

    // Create socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket failed");
        return -1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind the socket
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind failed");
        close(server_fd);
        return -1;
    }

    // Listen for incoming connections
    if (listen(server_fd, MAX_CLIENTS) < 0) {
        perror("listen failed");
        close(server_fd);
        return -1;
    }

    printf("Server is listening on port %d...\n", PORT);

    // Accept incoming connections and create a thread for each client
    while ((new_sock = accept(server_fd, (struct sockaddr *)&client_addr, &client_addr_len)) >= 0) {
        printf("Connection accepted from %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        // Allocate memory for the socket pointer and create a new thread
        new_sock_ptr = malloc(sizeof(int));
        *new_sock_ptr = new_sock;

        if (pthread_create(&thread_id, NULL, handle_client, (void *)new_sock_ptr) < 0) {
            perror("pthread_create failed");
            close(new_sock);
        }

        // Detach the thread to avoid memory leak
        pthread_detach(thread_id);
    }

    if (new_sock < 0) {
        perror("accept failed");
        close(server_fd);
        return -1;
    }

    close(server_fd);
    return 0;
}

