#include <stdio.h>
#include <stdlib.h>
#include <rpc/rpc.h>
#include "Password.h"

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <server_host> <password>\n", argv[0]);
        exit(1);
    }

    char *server_host = argv[1];
    char *password = argv[2];

    CLIENT *client;
    int *result;

    client = clnt_create(server_host, PASSWORD_PROG, PASSWORD_VERS, "udp");
    if (client == NULL) {
        clnt_pcreateerror(server_host);
        exit(1);
    }

    result = check_password_1(&password, client);
    if (result == NULL) {
        clnt_perror(client, "call failed");
        exit(1);
    }

    // Print the result
    if (*result) {
        printf("Password is correct.\n");
    } else {
        printf("Password is incorrect.\n");
    }

    clnt_destroy(client);
    return 0;
}

