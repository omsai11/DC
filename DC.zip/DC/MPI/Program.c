#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int n = 50; // Size of the array
    int *arr = NULL;
    int local_sum = 0, global_sum = 0;
    double average;
    double scatter_time, local_sum_time, reduce_time;

    // Initialize MPI
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Create array and initialize it with some values on the root process
    if (rank == 0) {
        arr = (int *)malloc(n * sizeof(int));
        printf("Array is :\n");
        for (int i = 0; i < n; i++) {
            arr[i] = i + 1;  
            printf("%d ",arr[i]);
        }printf("\n");
    }

    // Divide the array among processes
    int local_n = n / size; // Elements each process will handle

    // Create a buffer to store local array chunk
    int *local_arr = (int *)malloc(local_n * sizeof(int));

    // Time the Scatter operation
    double start_time = MPI_Wtime();
    MPI_Scatter(arr, local_n, MPI_INT, local_arr, local_n, MPI_INT, 0, MPI_COMM_WORLD);
    scatter_time = MPI_Wtime() - start_time;

    // Time the local sum calculation
    start_time = MPI_Wtime();
    for (int i = 0; i < local_n; i++) {
        local_sum += local_arr[i];
    }
    local_sum_time = MPI_Wtime() - start_time;

    // Time the Reduce operation
    start_time = MPI_Wtime();
    MPI_Reduce(&local_sum, &global_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
    reduce_time = MPI_Wtime() - start_time;

    // Print times for each process
    
    printf("Process %d - Scatter Time: %f seconds\tLocal Sum Time: %f seconds\tReduce Time: %f seconds\n", rank, scatter_time, local_sum_time, reduce_time);
    printf("Array for Process %d is :\n",rank);
    for(int i=0;i<local_n;i++)
    {
    printf("%d ",local_arr[i]);
    }
    printf("\n\n");

    // Root process computes the average
    if (rank == 0) {
        average = (double)global_sum / n;
        printf("The average of the array elements is: %f\n", average);
    }

    // Free memory
    free(local_arr);
    if (rank == 0) {
        free(arr); // Free the original array on the root process
    }

    // Finalize MPI
    MPI_Finalize();
    return 0;
}
