import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class PasswordCheckClient {

    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            

            PasswordCheck stub = (PasswordCheck) registry.lookup("PasswordCheck");


            Scanner scanner = new Scanner(System.in);
            while(true)
            {
            System.out.print("Enter password: ");
            String userPassword = scanner.nextLine();
            

            boolean isCorrect = stub.checkPassword(userPassword);

            if (isCorrect) {
                System.out.println("Password is correct!");
                 break;
            } else {
                System.out.println("Password is incorrect.");
               
            }
            
            }

            scanner.close();
        } catch (Exception e) {
            System.err.println("PasswordCheckClient exception: " + e.toString());
            e.printStackTrace();
        }
    }
}

