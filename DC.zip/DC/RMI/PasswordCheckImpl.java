import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class PasswordCheckImpl extends UnicastRemoteObject implements PasswordCheck {
    
    private static final String correctPassword = "Pass@1234";

    public PasswordCheckImpl() throws RemoteException {
        super();
    }

    @Override
    public boolean checkPassword(String password) throws RemoteException {
        return correctPassword.equals(password);
    }
}

