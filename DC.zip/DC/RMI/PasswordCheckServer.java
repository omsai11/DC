import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class PasswordCheckServer {
    
    public static void main(String[] args) {
        try {
            // Create an instance of the remote object
            PasswordCheckImpl obj = new PasswordCheckImpl();
            
            Registry registry = LocateRegistry.createRegistry(1099);  
            registry.rebind("PasswordCheck", obj);
            
            System.out.println("Password Check Server is ready...");
        } catch (Exception e) {
            System.err.println("PasswordCheckServer exception: " + e.toString());
            e.printStackTrace();
        }
    }
}

