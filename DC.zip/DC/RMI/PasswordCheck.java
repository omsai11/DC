import java.rmi.Remote;
import java.rmi.RemoteException;

public interface PasswordCheck extends Remote {
    boolean checkPassword(String password) throws RemoteException;
}

